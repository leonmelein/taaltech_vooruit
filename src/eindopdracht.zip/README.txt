EINDOPDRACHT TAALTECHNOLOGIE 2015
Léon Melein			:S2580861
Reinard van Dalen 	:S2497867
Aileen Bus 			:S2546167
Joost van Eck 		:S2519674

Gebruik van het programma:

1 Handmatige input van vragen:
$ python3 eindopdracht.py

2 Uitlezen van een bestand (2 mogelijkheden):
a) Uitlezen van een tab-seperated-file of plain-text-file:
	$ python3 eindopdracht filename.extension
b) Uitlezen via std.input (/pipes):
	$ cat filename.extension | python3 eindopdracht 